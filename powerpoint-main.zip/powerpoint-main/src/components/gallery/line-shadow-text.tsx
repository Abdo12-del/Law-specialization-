/**
 * مصدر: Magic UI (MIT) — apps/www/registry/magicui/line-shadow-text.tsx @ efe76fc
 * تكييف: framer-motion، cn من @/lib/cn، إطار الحركة line-shadow في src/styles/gallery.css.
 * الظل المخطّط نسخة من النص نفسه (attr(data-text)) — النص كتلة واحدة، آمن للعربية. لا تضف italic أو tracking.
 */
import { type CSSProperties, type HTMLAttributes } from 'react';
import { motion, type DOMMotionComponents, type MotionProps } from 'framer-motion';

import { cn } from '@/lib/cn';

const motionElements = {
  article: motion.article,
  div: motion.div,
  h1: motion.h1,
  h2: motion.h2,
  h3: motion.h3,
  h4: motion.h4,
  h5: motion.h5,
  h6: motion.h6,
  li: motion.li,
  p: motion.p,
  section: motion.section,
  span: motion.span,
} as const;

type MotionElementType = Extract<keyof DOMMotionComponents, keyof typeof motionElements>;

interface LineShadowTextProps extends Omit<HTMLAttributes<HTMLElement>, keyof MotionProps>, MotionProps {
  children: string;
  shadowColor?: string;
  as?: MotionElementType;
}

export function LineShadowText({ children, shadowColor = 'black', className, as: Component = 'span', ...props }: LineShadowTextProps) {
  const MotionComponent = motionElements[Component];

  return (
    <MotionComponent
      style={{ '--shadow-color': shadowColor } as CSSProperties}
      className={cn(
        'relative z-0 inline-flex',
        'after:absolute after:top-[0.04em] after:left-[0.04em] after:content-[attr(data-text)]',
        'after:bg-[linear-gradient(45deg,transparent_45%,var(--shadow-color)_45%,var(--shadow-color)_55%,transparent_0)]',
        'after:-z-10 after:bg-size-[0.06em_0.06em] after:bg-clip-text after:text-transparent',
        'after:animate-line-shadow',
        className,
      )}
      data-text={children}
      {...props}
    >
      {children}
    </MotionComponent>
  );
}
